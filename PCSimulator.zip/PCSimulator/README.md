# PC Simulator (Android)

1. Android Studio -> Open -> bu qovluğu seçin (PCSimulator).
2. Gradle soruşsa "Use default Gradle" seçin, Sync Project edin.
3. Telefonu USB ilə qoşun (USB debugging açıq), Run basın.
4. PC-Open düyməsi -> PC rejimi. Çıxış: terminalda `exit`, Start -> "Mobil moda dön" və ya geri düyməsi.

Brauzerdə sınaq: app/src/main/assets/www qovluğunda `python -m http.server 8000`, sonra localhost:8000.
