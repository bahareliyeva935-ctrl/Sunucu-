window.WindowManager = (function () {
  var layer = document.getElementById("windows");
  var wins = [], apps = {}, z = 10, count = 0;

  function focus(w) {
    wins.forEach(function (x) { x.el.classList.remove("active"); });
    w.el.classList.remove("min");
    w.el.classList.add("active");
    w.el.style.zIndex = ++z;
    Taskbar.render();
  }

  function toggleMax(w) {
    var s = w.el.style;
    if (w.max) {
      s.left = w.box.l; s.top = w.box.t; s.width = w.box.w; s.height = w.box.h;
    } else {
      w.box = { l: s.left, t: s.top, w: s.width, h: s.height };
      s.left = "0px"; s.top = "0px";
      s.width = layer.clientWidth + "px";
      s.height = layer.clientHeight + "px";
    }
    w.max = !w.max;
  }

  function close(w) {
    w.el.remove();
    wins.splice(wins.indexOf(w), 1);
    Taskbar.render();
  }

  function open(id) {
    var app = apps[id];
    if (!app) return;
    var el = document.createElement("div");
    var off = (count++ % 6) * 24;
    el.className = "win";
    el.style.cssText = "left:" + (60 + off) + "px;top:" + (30 + off) + "px;width:420px;height:280px";
    el.innerHTML =
      '<div class="bar"><span></span>' +
      '<button data-a="min">_</button><button data-a="max">[]</button><button data-a="close">x</button></div>' +
      '<div class="body"></div>' +
      ["n", "s", "e", "w", "ne", "nw", "se", "sw"].map(function (d) {
        return '<i class="h ' + d + '" data-d="' + d + '"></i>';
      }).join("");

    var w = { el: el, title: app.title, max: false, box: null };
    el.querySelector(".bar span").textContent = app.title;
    app.mount(el.querySelector(".body"));

    el.addEventListener("pointerdown", function () { focus(w); }, true);
    el.querySelector(".bar").addEventListener("click", function (e) {
      var a = e.target.dataset.a;
      if (a === "min") { el.classList.add("min"); el.classList.remove("active"); Taskbar.render(); }
      if (a === "max") toggleMax(w);
      if (a === "close") close(w);
    });

    DragResize.attach(w);
    layer.appendChild(el);
    wins.push(w);
    focus(w);
  }

  return {
    layer: layer, open: open, focus: focus, close: close,
    list: function () { return wins; },
    register: function (id, app) { apps[id] = app; }
  };
})();
