WindowManager.register("notes", {
  title: "Qeydlər",
  mount: function (box) {
    var KEY = "pcsim_notes";
    box.innerHTML = '<textarea class="note" placeholder="Qeydinizi yazın..."></textarea>';
    var ta = box.querySelector(".note");
    try { ta.value = localStorage.getItem(KEY) || ""; } catch (e) {}
    ta.addEventListener("input", function () {
      try { localStorage.setItem(KEY, ta.value); } catch (e) {}
    });
  }
});
