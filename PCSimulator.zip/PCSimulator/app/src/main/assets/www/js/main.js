document.getElementById("pc-open").addEventListener("click", function () {
  Bridge.enterPc();
});

document.getElementById("back-mobile").addEventListener("click", function () {
  document.getElementById("startmenu").classList.remove("open");
  Bridge.exitPc();
});

document.querySelectorAll(".icon").forEach(function (b) {
  b.addEventListener("click", function () { WindowManager.open(b.dataset.app); });
});
