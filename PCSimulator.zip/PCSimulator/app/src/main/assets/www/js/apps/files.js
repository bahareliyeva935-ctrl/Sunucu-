WindowManager.register("files", {
  title: "Fayllar",
  mount: function (box) {
    var root = {
      "Documents": { "readme.txt": "PC Simulator-a xoş gəlmisiniz.", "plan.txt": "1. Pəncərələr\n2. Tapşırıq çubuğu\n3. Terminal" },
      "Downloads": { "hello.txt": "Salam!" },
      "Pictures": {},
      "notes.txt": "Nümunə fayl."
    };
    var path = [];
    box.innerHTML = '<div class="files"></div>';
    var view = box.querySelector(".files");

    function here() {
      var n = root;
      path.forEach(function (p) { n = n[p]; });
      return n;
    }

    function add(label, fn) {
      var b = document.createElement("button");
      b.textContent = label;
      b.onclick = fn;
      view.appendChild(b);
    }

    function render() {
      view.innerHTML = "";
      var title = document.createElement("div");
      title.className = "path";
      title.textContent = "/" + path.join("/");
      view.appendChild(title);
      if (path.length) add(".. (geri)", function () { path.pop(); render(); });
      var node = here();
      Object.keys(node).forEach(function (k) {
        var isDir = typeof node[k] === "object";
        add((isDir ? "[qovluq] " : "[fayl] ") + k, function () {
          if (isDir) { path.push(k); render(); }
          else {
            view.innerHTML = "";
            var pre = document.createElement("div");
            pre.className = "txt";
            pre.textContent = node[k];
            view.appendChild(pre);
            add("Geri", render);
          }
        });
      });
    }
    render();
  }
});
