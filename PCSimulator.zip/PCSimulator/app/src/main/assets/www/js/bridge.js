(function () {
  var native = window.AndroidBridge; // Kotlin: addJavascriptInterface(..., "AndroidBridge")

  window.Bridge = {
    enterPc: function () { native ? native.enterPcMode() : window.onNativeMode(true); },
    exitPc:  function () { native ? native.exitPcMode()  : window.onNativeMode(false); }
  };

  // Android bu funksiyanı evaluateJavascript ilə çağırır
  window.onNativeMode = function (isPc) {
    document.documentElement.dataset.mode = isPc ? "pc" : "mobile";
    if (isPc && window.WindowManager && !document.querySelector(".win")) {
      WindowManager.open("terminal");
    }
  };
})();
