WindowManager.register("terminal", {
  title: "Terminal",
  mount: function (box) {
    box.innerHTML =
      '<div class="out"></div>' +
      '<input class="in" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="help">';
    var out = box.querySelector(".out");
    var inp = box.querySelector(".in");
    var hist = [], hi = 0;

    function print(text) {
      var d = document.createElement("div");
      d.textContent = text;
      out.appendChild(d);
      out.scrollTop = out.scrollHeight;
    }

    var cmds = {
      help:  function () { print("help, ls, date, clear, exit"); },
      ls:    function () { print("Documents  Downloads  notes.txt"); },
      date:  function () { print(new Date().toString()); },
      clear: function () { out.innerHTML = ""; },
      exit:  function () { print("Mobil rejimə qayıdılır..."); Bridge.exitPc(); }
    };

    inp.addEventListener("keydown", function (e) {
      if (e.key === "Enter") {
        var c = inp.value.trim();
        inp.value = "";
        if (!c) return;
        hist.push(c); hi = hist.length;
        print("$ " + c);
        (cmds[c] || function () { print(c + ": əmr tapılmadı"); })();
      } else if (e.key === "ArrowUp" && hi > 0) {
        inp.value = hist[--hi];
      } else if (e.key === "ArrowDown") {
        hi = Math.min(hi + 1, hist.length);
        inp.value = hist[hi] || "";
      }
    });
    setTimeout(function () { inp.focus(); }, 0);
  }
});
