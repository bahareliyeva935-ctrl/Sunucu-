window.DragResize = {
  attach: function (w) {
    var el = w.el, layer = WindowManager.layer;
    var MINW = 240, MINH = 160;

    el.addEventListener("pointerdown", function (e) {
      var h = e.target.dataset.d;
      var onBar = !!e.target.closest(".bar") && !e.target.closest("button");
      if ((!h && !onBar) || w.max) return;
      e.preventDefault();

      var t0 = e.target;
      var s = { x: e.clientX, y: e.clientY, l: el.offsetLeft, t: el.offsetTop,
                w: el.offsetWidth, h: el.offsetHeight };
      var W = layer.clientWidth, H = layer.clientHeight;
      t0.setPointerCapture(e.pointerId);

      function move(ev) {
        var dx = ev.clientX - s.x, dy = ev.clientY - s.y;
        var l = s.l, t = s.t, ww = s.w, hh = s.h;

        if (onBar) {
          l = s.l + dx; t = s.t + dy;
        } else {
          if (h.indexOf("e") > -1) ww = s.w + dx;
          if (h.indexOf("s") > -1) hh = s.h + dy;
          if (h.indexOf("w") > -1) ww = s.w - dx;
          if (h.indexOf("n") > -1) hh = s.h - dy;
          ww = Math.min(W, Math.max(MINW, ww));
          hh = Math.min(H, Math.max(MINH, hh));
          if (h.indexOf("w") > -1) l = s.l + s.w - ww;
          if (h.indexOf("n") > -1) t = s.t + s.h - hh;
        }
        l = Math.min(Math.max(0, l), W - ww);
        t = Math.min(Math.max(0, t), H - hh);

        el.style.left = l + "px";  el.style.top = t + "px";
        el.style.width = ww + "px"; el.style.height = hh + "px";
      }

      function up() {
        t0.removeEventListener("pointermove", move);
        t0.removeEventListener("pointerup", up);
        t0.removeEventListener("pointercancel", up);
      }
      t0.addEventListener("pointermove", move);
      t0.addEventListener("pointerup", up);
      t0.addEventListener("pointercancel", up);
    });
  }
};
