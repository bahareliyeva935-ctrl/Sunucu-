window.Taskbar = (function () {
  var tasks = document.getElementById("tasks");
  var menu = document.getElementById("startmenu");
  var clock = document.getElementById("clock");

  document.getElementById("start").addEventListener("click", function () {
    menu.classList.toggle("open");
  });

  function tick() {
    clock.textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  tick();
  setInterval(tick, 1000);

  function render() {
    tasks.innerHTML = "";
    WindowManager.list().forEach(function (w) {
      var b = document.createElement("button");
      var active = w.el.classList.contains("active");
      b.textContent = w.title;
      if (active) b.className = "on";
      b.onclick = function () {
        if (active) { w.el.classList.add("min"); w.el.classList.remove("active"); render(); }
        else WindowManager.focus(w);
      };
      tasks.appendChild(b);
    });
  }
  return { render: render };
})();
