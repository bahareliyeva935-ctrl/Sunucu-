package com.example.pcsim.bridge

import android.webkit.JavascriptInterface
import com.example.pcsim.MainActivity

class PcBridge(private val activity: MainActivity) {

    @JavascriptInterface
    fun enterPcMode() {
        activity.runOnUiThread { activity.setPcMode(true) }
    }

    @JavascriptInterface
    fun exitPcMode() {
        activity.runOnUiThread { activity.setPcMode(false) }
    }

    @JavascriptInterface
    fun isPcMode(): Boolean = activity.pcMode
}
