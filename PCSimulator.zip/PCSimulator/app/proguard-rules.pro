-keepclassmembers class com.example.pcsim.bridge.PcBridge {
    @android.webkit.JavascriptInterface <methods>;
}
